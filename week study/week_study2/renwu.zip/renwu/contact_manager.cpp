#include "contact_manager.h"

#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

void inputcontacts (vector<contact> &contacts){
    contact c;
    cout<<"����������:";
    getline(cin, c.name);

    cout<<"������绰:";
    getline(cin, c.telephone);

    cout<<"������qq������:";
    getline(cin, c.qq_or_email);

    contacts.push_back(c);
    cout<<"���ӳɹ�"<<endl;

    

   }








void printcontacts(vector<contact>& contacts){
    if(contacts.empty()){
        cout<<"ͨѶ¼��������ϵ��"<<endl;
        return;
    }


    for (int i =0;i < contacts.size();i++){
        cout << contacts[i].name << "|"
        <<contacts[i].telephone<< "|"
        <<contacts[i].qq_or_email <<endl;
    }
}

void findcontacts(const vector<contact>& contacts){
    string name;
    cout<<"��������Ҫ���ҵ���ϵ�ˣ�"<<endl;
    getline(cin, name);

    bool find = false;

    for (int i = 0;i<contacts.size();i++){
        if(contacts[i].name == name){
             cout << contacts[i].name << "|"
                 << contacts[i].telephone << "|"
                 << contacts[i].qq_or_email << endl;
                 find = true;

        }
    }
    if(!find){
        cout<<"ͨѶ¼���޸���ϵ��"<<endl;

    }
}

void erasecontacts(vector<contact>& contacts){
    string name;
    cout <<"������Ҫɾ������ϵ��"<<endl;
    getline(cin, name);

    for(int i = 0;i<contacts.size();i++){
        if (contacts[i].name == name){
            contacts.erase(contacts.begin() + i);
            cout<<"ɾ���ɹ�"<<endl;
            return;
        }
    }
    cout <<"δ�ҵ���ϵ��"<<endl;

}



bool savecontacts(const vector<contact>& contacts) {
    ofstream file("contacts.txt");

    if (!file) {
        cout << "�ļ���ʧ�ܣ�δ���档" << endl;
        return false;
    }

    for (int i = 0; i < contacts.size(); i++) {
        file << contacts[i].name << "|"
             << contacts[i].telephone << "|"
             << contacts[i].qq_or_email << '\n';
    }

    file.close();

    if (!file) {
        cout << "����ʧ�ܣ������ԡ�" << endl;
        return false;
    }

    cout << "����ɹ���" << endl;
    return true;
    
}


void loadcontacts(vector<contact>& contacts){
    ifstream file("contacts.txt");

    if(!file){
        cout<<"�޷���ͨѶ¼���޷�������ϵ��"<<endl;
        return;
    }
    string line;
    while(getline(file,line)){
        if(line.empty()){
            continue;
        }
        stringstream ss(line);
        contact c;

        if(!getline(ss,c.name,'|')||
            !getline(ss,c.telephone,'|')||
            !getline(ss,c.qq_or_email)){
            continue;
            }
        if (c.name.empty() ||
            c.telephone.empty() ||
            c.qq_or_email.empty() ||
            c.qq_or_email.find('|') != string::npos) {
            continue;
        }
        contacts.push_back(c);
        
    }
    if(file.bad()){
        cout<<"��ȡ�ļ�����"<<endl;
    }
}